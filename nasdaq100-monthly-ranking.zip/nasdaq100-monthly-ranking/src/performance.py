from datetime import timedelta

import pandas as pd
import yfinance as yf


def _get_close_series(download: pd.DataFrame, ticker: str) -> pd.Series:
    """Handle yfinance's single- and multi-ticker column layouts."""
    if isinstance(download.columns, pd.MultiIndex):
        level0 = download.columns.get_level_values(0)
        level1 = download.columns.get_level_values(1)
        if ticker in level0:
            return download[ticker]["Close"].dropna()
        if "Close" in level0 and ticker in level1:
            return download["Close"][ticker].dropna()
        raise KeyError(f"No Close column found for {ticker}")
    if "Close" not in download.columns:
        raise KeyError(f"No Close column found for {ticker}")
    return download["Close"].dropna()


def calculate_monthly_performance(constituents, period_start, period_end):
    """Return each constituent's adjusted-close return for the prior month.

    period_start/period_end are calendar dates for the target month.
    The baseline is the last available close strictly before period_start;
    the ending value is the last available close on or before period_end.
    """
    tickers = constituents["ticker"].tolist()

    # Include several preceding calendar days to find the previous month-end
    # trading close, and one day after month end for timezone/data-boundary safety.
    download_start = period_start - timedelta(days=10)
    download_end = period_end + timedelta(days=2)

    prices = yf.download(
        tickers=tickers,
        start=download_start.isoformat(),
        end=download_end.isoformat(),  # yfinance end is exclusive
        auto_adjust=True,
        group_by="ticker",
        threads=True,
        progress=False,
        actions=False,
    )

    rows = []
    for row in constituents.itertuples(index=False):
        ticker, company = row.ticker, row.company
        try:
            close = _get_close_series(prices, ticker)
            close.index = pd.to_datetime(close.index).tz_localize(None)
            close = close.sort_index()

            baseline = close[close.index.date < period_start]
            in_month = close[
                (close.index.date >= period_start) &
                (close.index.date <= period_end)
            ]
            if baseline.empty or in_month.empty:
                print(f"Skipping {ticker}: insufficient prices.")
                continue

            start_price = float(baseline.iloc[-1])
            end_price = float(in_month.iloc[-1])
            if start_price <= 0:
                continue

            performance = (end_price / start_price - 1.0) * 100.0
            rows.append({
                "Ticker": ticker,
                "Company": company,
                "Month-end adjusted close": end_price,
                "Monthly return (%)": performance,
                "Start reference close": start_price,
                "End date": in_month.index[-1].date().isoformat(),
            })
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            print(f"Skipping {ticker}: {exc}")

    result = pd.DataFrame(rows)
    if result.empty:
        return result
    return result.sort_values("Monthly return (%)", ascending=False).reset_index(drop=True)
