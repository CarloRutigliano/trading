from io import StringIO

import pandas as pd
import requests


WIKIPEDIA_URL = "https://en.wikipedia.org/wiki/Nasdaq-100"


def get_nasdaq100_constituents():
    """Fetch the current Nasdaq-100 membership table.

    Wikipedia is used as a convenient, keyless source. For production-critical
    use, consider replacing this with an official/licensed constituent feed.
    """
    response = requests.get(
        WIKIPEDIA_URL,
        headers={"User-Agent": "Nasdaq100MonthlyRanking/1.0 (personal research)"},
        timeout=30,
    )
    response.raise_for_status()

    tables = pd.read_html(StringIO(response.text))
    for table in tables:
        normalized = {str(c).strip().lower(): c for c in table.columns}
        ticker_col = next(
            (normalized[k] for k in ("ticker", "symbol") if k in normalized),
            None,
        )
        company_col = next(
            (normalized[k] for k in ("company", "company name", "security") if k in normalized),
            None,
        )
        if ticker_col is not None and company_col is not None:
            result = table[[ticker_col, company_col]].copy()
            result.columns = ["ticker", "company"]
            result["ticker"] = (
                result["ticker"].astype(str).str.strip().str.replace(".", "-", regex=False)
            )
            result["company"] = result["company"].astype(str).str.strip()
            result = result[result["ticker"].str.match(r"^[A-Z0-9-]+$")]
            result = result.drop_duplicates("ticker").reset_index(drop=True)
            if 90 <= len(result) <= 110:
                print(f"Loaded {len(result)} current Nasdaq-100 constituents.")
                return result

    raise RuntimeError(
        "Could not identify the Nasdaq-100 constituents table on Wikipedia. "
        "The page layout may have changed."
    )
