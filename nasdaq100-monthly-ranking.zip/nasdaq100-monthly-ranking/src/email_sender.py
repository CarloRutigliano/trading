import smtplib
from email.message import EmailMessage
from pathlib import Path


def send_email(subject, html_body, attachment_path, sender, app_password, recipient):
    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = sender
    message["To"] = recipient
    message.set_content("Your Nasdaq-100 monthly ranking is attached as a CSV.")
    message.add_alternative(html_body, subtype="html")

    path = Path(attachment_path)
    message.add_attachment(
        path.read_bytes(),
        maintype="text",
        subtype="csv",
        filename=path.name,
    )

    with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=30) as smtp:
        smtp.login(sender, app_password)
        smtp.send_message(message)
