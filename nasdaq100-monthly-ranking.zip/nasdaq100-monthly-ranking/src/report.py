from pathlib import Path
import html

import pandas as pd


def save_csv(ranking: pd.DataFrame, path: Path):
    ranking.to_csv(path, index=False, float_format="%.4f")


def build_html_report(top10: pd.DataFrame, period_start, period_end) -> str:
    rows = []
    for _, item in top10.iterrows():
        ret = float(item["Monthly return (%)"])
        color = "#16803c" if ret >= 0 else "#c0392b"
        rows.append(
            "<tr>"
            f"<td>{int(item['Rank'])}</td>"
            f"<td><strong>{html.escape(str(item['Ticker']))}</strong></td>"
            f"<td>{html.escape(str(item['Company']))}</td>"
            f'<td style="text-align:right;color:{color};font-weight:600">{ret:+.2f}%</td>'
            "</tr>"
        )

    table_rows = "\n".join(rows)
    return f"""
    <html>
      <body style="font-family:Arial,sans-serif;color:#202124;max-width:760px;margin:auto">
        <h2>Nasdaq-100 — Monthly Top 10</h2>
        <p>Performance period: <strong>{period_start:%d %B %Y}</strong> to
        <strong>{period_end:%d %B %Y}</strong>.</p>
        <p>Ranked by adjusted closing-price return, highest first.</p>
        <table cellpadding="10" cellspacing="0"
               style="border-collapse:collapse;width:100%;font-size:14px">
          <thead>
            <tr style="background:#f1f3f4;text-align:left">
              <th>Rank</th><th>Ticker</th><th>Company</th>
              <th style="text-align:right">Monthly return</th>
            </tr>
          </thead>
          <tbody>{table_rows}</tbody>
        </table>
        <p style="font-size:12px;color:#666;margin-top:24px">
          Data source: Yahoo Finance. Constituents: current Nasdaq-100 membership.
          Adjusted prices are used; historical membership is not reconstructed.
          This report is informational and is not investment advice.
        </p>
      </body>
    </html>
    """
