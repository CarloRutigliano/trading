# Nasdaq-100 Monthly Top 10

A GitHub Actions workflow that ranks the current Nasdaq-100 constituents by
their adjusted-close return for the previous calendar month and emails the top
10 as an HTML report with a CSV attachment.

## Methodology

- Universe: current Nasdaq-100 constituents fetched from Wikipedia.
- Prices: Yahoo Finance via `yfinance`, with `auto_adjust=True`.
- Return: last available adjusted close during the target month divided by the
  last available adjusted close strictly before the target month, minus 1.
- Ranking: descending monthly return.
- Schedule: first day of each month at 08:00 UTC.
- Manual run: GitHub Actions → Nasdaq-100 Monthly Top 10 → Run workflow.

This uses current constituents, not historical point-in-time membership. It is
therefore not a survivorship-bias-free historical backtest. Yahoo Finance and
Wikipedia are convenient public sources, not guaranteed market-data services.

## Setup

1. Create a private GitHub repository and upload this project.
2. In Gmail, enable 2-Step Verification and create an **App Password**.
   Do not use your normal Gmail password.
3. In GitHub, open Settings → Secrets and variables → Actions → New repository secret.
4. Add these three repository secrets:

   | Secret | Value |
   |---|---|
   | `EMAIL_USER` | Gmail address used to send the report |
   | `EMAIL_APP_PASSWORD` | Gmail App Password (spaces removed) |
   | `EMAIL_TO` | Destination email address |

5. Open Actions and enable workflows if GitHub asks.
6. Run the workflow manually once to test it.

## Notes

- GitHub Actions cron uses UTC and may start later than the exact scheduled time
  during periods of high GitHub load.
- The first-day schedule reports the previous completed calendar month.
- The workflow can be run manually at any time; it still reports the previous
  calendar month.
- If the public constituent table or Yahoo Finance changes its format/access,
  the workflow may need maintenance.
- The CSV is uploaded as a GitHub Actions artifact for 90 days.
