from datetime import date
from pathlib import Path
import os

from src.constituents import get_nasdaq100_constituents
from src.performance import calculate_monthly_performance
from src.report import build_html_report, save_csv
from src.email_sender import send_email


def previous_calendar_month(today: date):
    first_this_month = today.replace(day=1)
    last_previous_month = first_this_month.fromordinal(first_this_month.toordinal() - 1)
    first_previous_month = last_previous_month.replace(day=1)
    return first_previous_month, last_previous_month


def main():
    today = date.today()
    period_start, period_end = previous_calendar_month(today)
    print(f"Calculating performance for {period_start:%Y-%m}...")

    constituents = get_nasdaq100_constituents()
    ranking = calculate_monthly_performance(
        constituents,
        period_start=period_start,
        period_end=period_end,
    )

    if ranking.empty:
        raise RuntimeError("No valid monthly performance data was returned.")

    top10 = ranking.head(10).copy()
    top10.insert(0, "Rank", range(1, len(top10) + 1))

    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    csv_path = output_dir / f"nasdaq100_top10_{period_start:%Y_%m}.csv"
    save_csv(top10, csv_path)

    subject = f"Nasdaq-100 Top 10 — {period_start:%B %Y}"
    html = build_html_report(top10, period_start, period_end)

    send_email(
        subject=subject,
        html_body=html,
        attachment_path=csv_path,
        sender=os.environ["EMAIL_USER"],
        app_password=os.environ["EMAIL_APP_PASSWORD"],
        recipient=os.environ["EMAIL_TO"],
    )

    print(f"Email sent to {os.environ['EMAIL_TO']}. CSV: {csv_path}")


if __name__ == "__main__":
    main()
